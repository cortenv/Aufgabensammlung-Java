package ch.ictbz.blj.java.blogapi;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;


public class Main {

    private static final String API_URL = "http://041er-blj.ch/2020/urnussbaumer/blog/api";

    public static void main(String[] args) throws IOException {

        String jsonString = requestJSONFromAPI();
        JSONArray array = (JSONArray)JSONValue.parse(jsonString);

        for (int i = 0; i < array.size() - 1; i++) {
            JSONObject obj = (JSONObject)array.get(i);
            System.out.println("Beitrag von: " + obj.get("created_by"));
            System.out.println("Erstellt am: " + obj.get("created_at"));
            System.out.println("Titel: " + obj.get("post_title"));
            System.out.println("--------------------------------");
            System.out.println(obj.get("post_text"));
            System.out.println();

        }
    }

    private static String requestJSONFromAPI() throws IOException {

        URL url = new URL(API_URL);

        // open URL stream
        InputStream input = url.openStream();
        BufferedReader in = new BufferedReader(new InputStreamReader(input));
        String data = in.readLine();

        return data;
    }
}
